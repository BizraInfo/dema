# Dema

**Your sovereign AI node companion.**

Dema helps you run a private AI workspace on your own machine — with memory, safe actions, receipts, and a clear next step.

No coding required.  
No hidden autonomy.  
No action without your consent.  
No cloud dependency in local mode.

```text
Install Dema
→ create your local profile
→ connect a local model
→ see your node health
→ approve one bounded action
→ receive your first proof receipt
```

Dema is the first public product of BIZRA.

**BIZRA is the ecosystem. Dema is the door.**

---

## Why Dema exists

Most AI tools ask you to trust them.

Dema shows you what is true:

- what is ready
- what is blocked
- what is safe
- what needs consent
- what happened
- what did not happen
- where the receipt is

Dema is designed for people who want useful AI without surrendering sovereignty, privacy, or clarity.

---

## What Dema does in v0.1

Dema v0.1 is a local-first product shell for your sovereign AI node.

It can:

- create your local Dema profile
- record a daily continuity tick
- detect local model backends such as LM Studio or Ollama
- show node readiness
- show whether the daemon is stopped or running
- show the explicit activation gate
- propose one bounded diagnostic mission
- display proof receipts
- explain the next admissible action

It does **not** claim AGI.  
It does **not** launch a token.  
It does **not** activate a public network.  
It does **not** run hidden background autonomy.  
It does **not** act without consent.

---

## Install experience goal

For non-technical users:

```text
Download → Install → Open Dema → Follow guided setup
```

For developers:

```bash
git clone https://github.com/BizraInfo/dema
cd dema
pnpm install
pnpm dev
```

---

## First user promise

```text
Dema helps you run your own local AI node, safely.
It remembers your context, asks before acting, and proves what changed.
```

---

## Product principles

1. Local-first by default
2. Consent before action
3. Proof before claim
4. Memory with permission
5. Simple surface, deep architecture
6. No hidden autonomy
7. No hype claims
8. Receipts over trust
9. Human sovereignty first
10. Ihsan in every gate

---

## The first receipt moment

The first unforgettable Dema moment:

```text
Dema: Your node is ready.
Dema: I can run one bounded diagnostic mission.
Dema: Say GO if you approve.
User: GO.
Dema: Done. Here is the receipt. Here is what changed. Here is what did not happen.
```

That is the product.

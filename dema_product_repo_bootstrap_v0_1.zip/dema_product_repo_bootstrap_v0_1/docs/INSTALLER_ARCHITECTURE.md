# Dema Unified Installer Architecture v0.1

## Goal

Dema must work for users with no coding experience.

The primary path:

```text
Download → Install → Open Dema → Guided setup → Local node ready
```

## Supported user levels

### Level 1 — Non-technical user

- double-click installer
- wizard UI
- no terminal
- no Python knowledge
- no Docker requirement

### Level 2 — technical user

```bash
curl -fsSL https://install.dema.ai | sh
```

```powershell
irm https://install.dema.ai | iex
```

### Level 3 — developer

```bash
git clone https://github.com/BizraInfo/dema
pnpm install
pnpm dev
```

## Local instance directory

```text
~/.dema/
  config.local.yaml
  profile.json
  receipts/
  memory/
  logs/
  models/
  skills/
```

## Installer v0.1 responsibilities

- detect OS
- detect CPU/RAM/disk
- create local state directory
- create profile
- ask memory consent
- detect LM Studio/Ollama
- run local readiness check
- launch local console
- create receipt folder
- provide uninstall path

## Installer must not

- start hidden background daemon
- send private files to cloud
- make token/economic claims
- modify unrelated directories
- install unreviewed skills
- delete receipts without explicit confirmation

## First-run wizard

```text
1. Welcome
2. Choose local/private mode
3. Create profile
4. Detect model backend
5. Health check
6. Show node status
7. Offer one bounded diagnostic action
8. Ask consent
9. Generate first receipt
```

## Update security

- signed installers
- signed update metadata
- checksum verification
- no automatic major upgrades
- user-visible release notes
- rollback path

# Dema Product Strategy v0.1

## Strategic thesis

BIZRA is too large to be the first public product surface. Dema must become the clean, installable, human-facing entry point.

```text
BIZRA = the ecosystem
Node0 = the proof
Dema = the door
Installer = the bridge
README = the first handshake
```

## Product positioning

**Dema — your sovereign AI node companion.**

Tagline:

```text
Local-first. Consent-bound. Receipt-backed.
```

## Category

Dema is not a generic chatbot, coding agent, or dashboard.

Dema is a local-first node companion that combines:

- persistent memory
- local model readiness
- mission proposal
- consent gates
- proof receipts
- safe monetization guidance
- human continuity

## Competitive pattern extraction

### From Pi

Admit:

- minimal harness
- extensible package model
- project-local context
- JSON/RPC/SDK modes
- branchable mission/session history

Reject:

- no permission gate
- uncontrolled packages
- developer-only assumptions

### From Hermes

Admit:

- persistent memory
- skill creation from experience
- user model continuity
- repeated-success learning
- gateway continuity

Reject:

- memory without proof boundary
- skills without FATE review
- generic agent framing

### BIZRA-native moat

Dema adds:

- FATE consent gate
- Ihsan restraint
- identity-bound receipts
- proof-before-claim
- local sovereignty
- monetization guardian

## First product loop

```text
Remember → Inspect → Propose → Ask Consent → Act Boundedly → Prove → Learn → Next Action
```

## First marketable offer

```text
Sovereign Local AI Node Setup + Safety Audit
```

Deliverable:

- Dema installed
- local model connected
- local profile created
- readiness report produced
- first bounded diagnostic receipt generated
- plain-language safety report delivered

## Forbidden launch claims

- AGI
- passive income
- token appreciation
- guaranteed security
- autonomous public network
- Proof-of-Impact rewards before receipt-ledger proof

## North-star user reaction

```text
I understand what this is.
I can install it.
It runs locally.
It asks before acting.
It proves what happened.
```

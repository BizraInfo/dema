# Dema Repo Architecture v0.1

## Repo purpose

`dema` is the product repo.

It should be simple, professional, installable, and readable by non-technical users.

`bizra-data-lake` remains the forge, archive, proof spine, and research/history repo.

## Target layout

```text
dema/
  README.md
  LICENSE
  SECURITY.md
  CONTRIBUTING.md
  CHANGELOG.md

  apps/
    cli/
    desktop/
    local-console/

  packages/
    core/
    installer/
    node-adapter/
    model-adapters/
    memory/
    mission-space/
    fate/
    receipts/
    skills/
    ui/

  adapters/
    bizra-node0/
    lm-studio/
    ollama/
    filesystem/

  templates/
    node.template.yaml
    agents.template.yaml
    skills.template.yaml

  docs/
    PRODUCT.md
    INSTALL.md
    ARCHITECTURE.md
    DEMA_CONSTITUTION.md
    ROADMAP.md
    GTM.md

  scripts/
    install/
    release/

  tests/
    unit/
    integration/
    installer/
```

## Monorepo split rule

Do not move all of `bizra-data-lake` into Dema.

Copy only product-safe contracts:

- Dema Constitution
- Node0 status schema
- receipt viewer schema
- profile/tick flow
- safe monetization guardian
- Node0 adapter interface

Backend runtime extraction comes later as `bizra-node-runtime`.

## Product boundary

```text
Dema talks to Node0Adapter.
Node0Adapter talks to runtime.
Runtime enforces FATE.
Receipts decide truth.
```

Dema never directly performs dangerous execution.

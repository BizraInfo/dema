# Dema GTM Plan v0.1

## Core GTM decision

Do not market the full BIZRA ecosystem first.

Market Dema first.

## Positioning

```text
Dema — run your own private AI node in minutes.
Local-first. Consent-bound. Receipt-backed.
```

## First offer

```text
Sovereign Local AI Node Setup + Safety Audit
```

## Audience

- AI builders
- privacy-focused founders
- researchers
- cybersecurity professionals
- local AI power users
- small technical teams

## Offer deliverables

- Dema installed
- local model connected
- node readiness verified
- first bounded diagnostic receipt generated
- safety report delivered
- next-step roadmap provided

## First public asset sequence

1. README as landing page
2. 90-second proof video
3. setup + safety audit page
4. private alpha waitlist
5. 3 lighthouse users
6. case studies from receipts

## Launch boundaries

Dema v0.1 must not claim:

- AGI
- public network activation
- token rewards
- passive income
- guaranteed security
- economic returns

## Success metrics

- README comprehension in 60 seconds
- install completion rate
- first node readiness success
- first receipt generated
- user trust score
- support burden per install
- number of blocked unsafe actions clearly explained

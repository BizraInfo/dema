# Security Policy

Dema is local-first and consent-bound.

## Security principles

- no hidden autonomy
- no action without consent
- no unsigned updates
- no secrets in repository
- no third-party skill execution without trust review
- local-only mode must not require cloud credentials
- receipts must not be deleted without explicit user confirmation

## Reporting

Open a private security advisory or contact the maintainers before public disclosure.

# Dema Roadmap

## v0.1 Alpha

- README as product landing page
- CLI shell
- Node0 status adapter
- receipt viewer stub
- profile/tick setup flow
- local console prototype
- installer architecture

## v0.2

- desktop shell
- first-run wizard
- LM Studio/Ollama detection
- local receipt drawer
- mission proposal UI

## v0.3

- bounded diagnostic flow
- receipt verification UI
- memory/season summary
- monetization guardian

## Later

- mobile companion
- mission spaces
- skill registry
- lighthouse user onboarding
- Node1/federation only after Node0 receipts

# Dema CLI v0.1

Initial commands:

```bash
dema setup
dema status
dema today
dema doctor
dema receipts
dema mission propose
dema monetize
```

The CLI must be safe-by-default:

- status commands are read-only
- mission run requires exact consent phrase
- no hidden daemon start
- no external routing by default
- no token/economic claims

import type { MissionProposal, Node0Adapter, Node0Status, ReceiptSummary } from "./types";

export class LocalNode0Adapter implements Node0Adapter {
  constructor(private readonly commandRunner: (args: string[]) => Promise<string>) {}

  async status(): Promise<Node0Status> {
    const raw = await this.commandRunner([
      "python",
      "-m",
      "core.sovereign",
      "node0",
      "status",
      "--json",
      "--root",
      "sovereign_state/dema",
    ]);

    const parsed = JSON.parse(raw) as Record<string, unknown>;

    return {
      schema: "bizra.dema.node0_status.v0.1",
      node: "Node0",
      ready: Boolean(parsed.ready),
      consoleReady: Boolean(parsed.console_ready),
      activationGate: String(parsed.activation_gate ?? "BLOCKED") as Node0Status["activationGate"],
      daemonStatus: String(parsed.daemon_status ?? "unknown") as Node0Status["daemonStatus"],
      findings: Array.isArray(parsed.findings) ? parsed.findings.map(String) : [],
      nextAdmissibleAction: String(parsed.next_admissible_action ?? ""),
    };
  }

  async proposeBoundedDiagnostic(): Promise<MissionProposal> {
    return {
      schema: "bizra.dema.mission_proposal.v0.1",
      id: "node0-bounded-diagnostic-001",
      title: "Run one bounded Node0 diagnostic mission",
      scope: "bounded_diagnostic",
      allowedActions: ["bounded diagnostic mission", "runtime receipt creation", "post-run status verification"],
      forbiddenActions: ["Node1", "public demo", "external provider routing", "token/economic claims"],
      requiredConsentPhrase: "GO: Node0 bounded diagnostic activation only",
    };
  }

  async runBoundedDiagnostic(consentPhrase: string): Promise<ReceiptSummary> {
    if (consentPhrase !== "GO: Node0 bounded diagnostic activation only") {
      throw new Error("Explicit consent phrase mismatch. Refusing bounded diagnostic activation.");
    }

    // Runtime execution intentionally belongs behind the existing BIZRA Node0 runtime.
    // This adapter should call the hardened runtime command only after ARTIFACT-011 scope is accepted.
    throw new Error("Runtime execution adapter not implemented in product shell v0.1.");
  }

  async listReceipts(): Promise<ReceiptSummary[]> {
    return [];
  }
}

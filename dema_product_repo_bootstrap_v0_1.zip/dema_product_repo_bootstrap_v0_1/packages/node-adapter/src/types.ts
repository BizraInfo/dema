export type ActivationGate = "EXPLICIT_GO_REQUIRED" | "OPEN" | "BLOCKED";
export type DaemonStatus = "stopped" | "running" | "unknown";

export interface Node0ModelStatus {
  connected: boolean;
  baseUrl?: string;
  loadedModelIds: string[];
}

export interface Node0RustBusStatus {
  ready: boolean;
  subscribers?: number;
  ihsan?: number;
}

export interface Node0Status {
  schema: "bizra.dema.node0_status.v0.1";
  node: "Node0" | string;
  human?: string;
  ready: boolean;
  consoleReady: boolean;
  activationGate: ActivationGate;
  daemonStatus: DaemonStatus;
  findings: string[];
  model?: Node0ModelStatus;
  rustBus?: Node0RustBusStatus;
  latestReceiptHash?: string;
  nextAdmissibleAction?: string;
}

export interface MissionProposal {
  schema: "bizra.dema.mission_proposal.v0.1";
  id: string;
  title: string;
  scope: "bounded_diagnostic" | "read_only" | "blocked";
  allowedActions: string[];
  forbiddenActions: string[];
  requiredConsentPhrase: string;
}

export interface ReceiptSummary {
  schema: "bizra.dema.receipt_summary.v0.1";
  id: string;
  path: string;
  action: string;
  truthLabel: "MEASURED" | "DERIVED" | "DIRECTION" | "PENDING";
  hash?: string;
  createdAt?: string;
}

export interface Node0Adapter {
  status(): Promise<Node0Status>;
  proposeBoundedDiagnostic(): Promise<MissionProposal>;
  runBoundedDiagnostic(consentPhrase: string): Promise<ReceiptSummary>;
  listReceipts(): Promise<ReceiptSummary[]>;
}

# Contributing to Dema

Thank you for helping build Dema.

## Rules

- Keep the user experience simple.
- Keep runtime power behind consent gates.
- Add tests for every safety boundary.
- Do not introduce hidden background autonomy.
- Do not add token/economic claims.
- Do not ship unreviewed third-party skill execution.

## Local development

```bash
pnpm install
pnpm test
pnpm lint
```
